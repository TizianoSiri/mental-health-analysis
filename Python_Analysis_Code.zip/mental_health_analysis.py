import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import chi2_contingency
import statsmodels.api as sm

# Load the dataset
survey_df_cleaned = pd.read_csv('path/to/survey.csv')  # Replace with the correct file path

# Data Cleaning
survey_df_cleaned = survey_df_cleaned[(survey_df_cleaned['Age'] >= 18) & (survey_df_cleaned['Age'] <= 100)]
survey_df_cleaned['work_interfere'].fillna('Unknown', inplace=True)
survey_df_cleaned['self_employed'].fillna('No Response', inplace=True)

# Encode categorical variables
survey_df_cleaned['benefits_encoded'] = survey_df_cleaned['benefits'].apply(lambda x: 1 if x == 'Yes' else 0)
survey_df_cleaned['supervisor_encoded'] = survey_df_cleaned['supervisor'].apply(lambda x: 1 if x == 'Yes' else 0)
survey_df_cleaned['remote_work_encoded'] = survey_df_cleaned['remote_work'].apply(lambda x: 1 if x == 'Yes' else 0)

# Descriptive statistics and visualization
work_interfere_counts = survey_df_cleaned['work_interfere'].value_counts()
plt.figure(figsize=(8, 5))
work_interfere_counts.plot(kind='bar', color='skyblue', edgecolor='black')
plt.title('Frequency of Work Interference Due to Mental Health')
plt.show()

# Cross-tabulations and chi-square tests
benefits_treatment_ct = pd.crosstab(survey_df_cleaned['benefits'], survey_df_cleaned['treatment'])
chi2_benefits, p_benefits, _, _ = chi2_contingency(benefits_treatment_ct)
cramers_v_benefits = np.sqrt(chi2_benefits / (survey_df_cleaned.shape[0] * (min(benefits_treatment_ct.shape) - 1)))

# Logistic Regression Analysis
X_treatment = survey_df_cleaned[['benefits_encoded', 'supervisor_encoded', 'remote_work_encoded']]
X_treatment = sm.add_constant(X_treatment)
y_treatment = survey_df_cleaned['treatment'].apply(lambda x: 1 if x == 'Yes' else 0)
model_treatment = sm.Logit(y_treatment, X_treatment).fit()
print(model_treatment.summary())
